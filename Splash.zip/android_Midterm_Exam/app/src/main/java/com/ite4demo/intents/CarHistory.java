package com.ite4demo.intents;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class CarHistory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_history);
        String History;
        Bundle extras = getIntent().getExtras();
        History = extras.getString("History");

        setContentView(R.layout.activity_car_history);

        Toast.makeText(this, History + " selected", Toast.LENGTH_LONG).show();


        TextView tv = (TextView) findViewById(R.id.textView);


        tv.setText(History);
    }
}