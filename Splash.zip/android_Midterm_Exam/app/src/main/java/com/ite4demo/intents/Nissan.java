package com.ite4demo.intents;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Nissan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nissan);
        String Nissan;
        Bundle extras = getIntent().getExtras();
        Nissan = extras.getString("Nissan");

        setContentView(R.layout.activity_nissan);

        Toast.makeText(this, Nissan+ " selected", Toast.LENGTH_LONG).show();


        TextView tv = (TextView) findViewById(R.id.textView8);


        tv.setText(Nissan);
    }
}
