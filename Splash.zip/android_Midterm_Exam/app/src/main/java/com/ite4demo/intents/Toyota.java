package com.ite4demo.intents;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Toyota extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toyota);
        String Toyota;
        Bundle extras = getIntent().getExtras();
        Toyota = extras.getString("Toyota");

        setContentView(R.layout.activity_toyota);

        Toast.makeText(this, Toyota + " selected", Toast.LENGTH_LONG).show();


        TextView tv = (TextView) findViewById(R.id.textView4);


        tv.setText(Toyota);

    }
}
