package com.ite4demo.intents;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Mitsubishi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mitsubishi);
            String Mistsubishi;
            Bundle extras = getIntent().getExtras();
            Mistsubishi = extras.getString("Mitsubishi");

            setContentView(R.layout.activity_mitsubishi);

            Toast.makeText(this, Mistsubishi + " selected", Toast.LENGTH_LONG).show();


            TextView tv = (TextView) findViewById(R.id.textView6);


            tv.setText(Mistsubishi);

        }
    }
